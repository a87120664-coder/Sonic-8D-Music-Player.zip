# Sonic 8D Music Player

A dark-themed Android local music player starter project built with Kotlin, Jetpack Compose and AndroidX Media3.

## Current starter features
- Local audio library permission and MediaStore scan
- Basic play, pause, previous and next
- Dark neon interface
- Circular visualizer foundation
- 8D mode UI switch (actual HRTF/spatial DSP is not implemented in this starter)
- Reserved bottom banner-ad area (real AdMob integration requires your AdMob App ID and Banner Ad Unit ID)

## Build
Open this project in Android Studio, or use the included GitHub Actions workflow after adding it to your repository.

## Important
The current 8D switch is a UI placeholder. It does not yet apply true 3D/HRTF audio processing. That needs a dedicated audio DSP stage and testing on wired and Bluetooth headphones. The visualizer is also a visual foundation, not yet synchronized to live audio spectrum.

Do not publish with placeholder ad IDs. Add your own AdMob IDs and complete Google's app setup and policy requirements first.

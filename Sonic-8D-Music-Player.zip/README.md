# Sonic 8D Music Player — v5

Features in this build:
- Local music library and ExoPlayer playback
- Animated splash/logo and playback spectrum visualizer
- Device-supported Equalizer and BassBoost controls
- Song and artist search
- Favorites saved locally on device
- Playlist name creation/list/removal (playlist organization UI; adding individual tracks to named playlists is a future enhancement)
- Bottom banner ad placeholder only; no live AdMob integration until the owner's valid AdMob App ID and Banner Ad Unit ID are configured

Limitations: true HRTF/binaural 8D spatial processing is not implemented yet. Audio effects and spectrum access depend on Android device support and permissions.

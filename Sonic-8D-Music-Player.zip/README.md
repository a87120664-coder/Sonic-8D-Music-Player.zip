# Sonic 8D Music Player — v5

Features in this build:
- Local music library and ExoPlayer playback
- Animated splash/logo and playback spectrum visualizer
- Device-supported Equalizer and BassBoost controls
- Song and artist search
- Favorites saved locally on device
- Playlist name creation/list/removal (playlist organization UI; adding individual tracks to named playlists is a future enhancement)
- Bottom banner ad placeholder only; no live AdMob integration until the owner's valid AdMob App ID and Banner Ad Unit ID are configured

Limitations: true HRTF/binaural 8D spatial processing is not implemented yet. Audio effects and spectrum access depend on Android device support and permissions.


Version 7 update: uses the supplied music-note app logo and publishes track title, artist, and app-logo artwork through an Android Media3 MediaSession for system/lock-screen media controls. Lock-screen layout and artwork presentation are controlled by Android and vary by device. A persistent foreground playback service/notification is not yet included.

package com.sonic8d.music

import android.Manifest
import android.media.audiofx.Visualizer
import android.media.audiofx.Equalizer
import android.media.audiofx.BassBoost
import android.os.Handler
import android.os.Looper
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.Snapshot
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

private data class Track(val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            SonicTheme {
                var splashVisible by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) {
                    delay(2400)
                    splashVisible = false
                }
                Box(Modifier.fillMaxSize()) {
                    SonicApp(
                        loadTracks = { queryAudio() },
                        player = player!!,
                        hasPermission = { audioPermissionGranted() }
                    )
                    AnimatedVisibility(
                        visible = splashVisible,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        SonicSplash()
                    }
                }
            }
        }
    }

    private fun audioPermissionGranted(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun queryAudio(): List<Track> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val result = mutableListOf<Track>()
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown title"
                val artist = cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
                result += Track(title, artist, Uri.withAppendedPath(collection, id.toString()))
            }
        }
        return result
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@Composable
private fun SonicTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Color(0xFFB78CFF),
        secondary = Color(0xFF55D6FF),
        background = Color(0xFF090911),
        surface = Color(0xFF151522)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
private fun SonicApp(
    loadTracks: () -> List<Track>,
    player: ExoPlayer,
    hasPermission: () -> Boolean
) {
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var selected by remember { mutableIntStateOf(-1) }
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("sonic8d_library", android.content.Context.MODE_PRIVATE) }
    var favoriteIds by remember { mutableStateOf(preferences.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var searchQuery by remember { mutableStateOf("") }
    var favoritesOnly by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    var showCreatePlaylist by remember { mutableStateOf(false) }
    var playlists by remember { mutableStateOf(preferences.getStringSet("playlists", emptySet())?.toSet() ?: emptySet()) }
    var showPlaylists by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var eightD by remember { mutableStateOf(false) }
    var equalizerOpen by remember { mutableStateOf(false) }
    var equalizerEffect by remember { mutableStateOf<Equalizer?>(null) }
    var bassBoostEffect by remember { mutableStateOf<BassBoost?>(null) }
    var eqRange by remember { mutableStateOf(-15f..15f) }
    var eqFrequencies by remember { mutableStateOf(emptyList<String>()) }
    val eqLevels = remember { mutableStateListOf<Float>() }
    var bassLevel by remember { mutableFloatStateOf(0f) }
    var eqAvailable by remember { mutableStateOf(false) }
    var permissionGranted by remember { mutableStateOf(hasPermission()) }
    var visualizerPermissionGranted by remember { mutableStateOf(false) }
    val spectrumBars = remember { mutableStateListOf<Float>().apply { repeat(48) { add(0.06f) } } }

    val visualizerPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted -> visualizerPermissionGranted = granted }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted) tracks = loadTracks()
    }

    fun askForAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        permissionLauncher.launch(permission)
    }

    fun toggleFavorite(track: Track) {
        val key = track.uri.toString()
        favoriteIds = if (key in favoriteIds) favoriteIds - key else favoriteIds + key
        preferences.edit().putStringSet("favorites", favoriteIds).apply()
    }

    fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        selected = index
        player.setMediaItem(MediaItem.fromUri(tracks[index].uri))
        player.prepare()
        player.play()
        playing = true
        if (!visualizerPermissionGranted) {
            visualizerPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    DisposableEffect(player.audioSessionId, selected, playing) {
        var eq: Equalizer? = null
        var bass: BassBoost? = null
        try {
            val sessionId = player.audioSessionId
            if (sessionId != 0) {
                eq = Equalizer(0, sessionId).apply { enabled = true }
                bass = BassBoost(0, sessionId).apply { enabled = true }
                val bandCount = eq.numberOfBands.toInt()
                val range = eq.bandLevelRange
                val minLevel = range[0] / 100f
                val maxLevel = range[1] / 100f
                equalizerEffect = eq
                bassBoostEffect = bass
                eqRange = minLevel..maxLevel
                eqFrequencies = (0 until bandCount).map { band ->
                    val hz = eq.getCenterFreq(band.toShort()) / 1000
                    if (hz >= 1000) "${hz / 1000f} kHz" else "$hz Hz"
                }
                Snapshot.withMutableSnapshot {
                    eqLevels.clear()
                    repeat(bandCount) { eqLevels.add(0f) }
                }
                eqAvailable = bandCount > 0
            }
        } catch (_: Exception) {
            eqAvailable = false
        }
        onDispose {
            try { equalizerEffect?.enabled = false } catch (_: Exception) { }
            try { bassBoostEffect?.enabled = false } catch (_: Exception) { }
            try { eq?.release() } catch (_: Exception) { }
            try { bass?.release() } catch (_: Exception) { }
            equalizerEffect = null
            bassBoostEffect = null
        }
    }

    LaunchedEffect(permissionGranted) {
        if (permissionGranted) tracks = loadTracks()
    }

    DisposableEffect(selected, playing, visualizerPermissionGranted) {
        var audioVisualizer: Visualizer? = null
        if (playing && selected >= 0 && visualizerPermissionGranted) {
            try {
                audioVisualizer = Visualizer(player.audioSessionId).apply {
                    captureSize = Visualizer.getCaptureSizeRange()[1]
                    setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int) = Unit
                        override fun onFftDataCapture(visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                            if (fft == null || fft.size < 8) return
                            val values = FloatArray(48)
                            for (bar in values.indices) {
                                val bin = (2.0 * Math.pow(fft.size / 2.0, bar / 47.0)).toInt().coerceIn(2, fft.size - 2)
                                val real = fft[bin].toInt().toFloat()
                                val imaginary = fft[bin + 1].toInt().toFloat()
                                val magnitude = kotlin.math.sqrt(real * real + imaginary * imaginary) / 128f
                                values[bar] = (magnitude * 2.8f).coerceIn(0.06f, 1f)
                            }
                            Handler(Looper.getMainLooper()).post {
                                Snapshot.withMutableSnapshot {
                                    values.forEachIndexed { index, value -> spectrumBars[index] = value }
                                }
                            }
                        }
                    }, Visualizer.getMaxCaptureRate() / 2, false, true)
                    enabled = true
                }
            } catch (_: Exception) {
                audioVisualizer?.release()
                audioVisualizer = null
            }
        } else {
            spectrumBars.indices.forEach { spectrumBars[it] = 0.06f }
        }
        onDispose {
            try { audioVisualizer?.enabled = false } catch (_: Exception) { }
            try { audioVisualizer?.release() } catch (_: Exception) { }
        }
    }

    if (showCreatePlaylist) {
        AlertDialog(
            onDismissRequest = { showCreatePlaylist = false },
            containerColor = Color(0xFF171522),
            title = { Text("NEW PLAYLIST", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = playlistName,
                    onValueChange = { playlistName = it },
                    singleLine = true,
                    label = { Text("Playlist name") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val name = playlistName.trim()
                    if (name.isNotEmpty()) {
                        playlists = playlists + name
                        preferences.edit().putStringSet("playlists", playlists).apply()
                    }
                    playlistName = ""
                    showCreatePlaylist = false
                }) { Text("CREATE") }
            },
            dismissButton = { TextButton(onClick = { showCreatePlaylist = false }) { Text("CANCEL") } }
        )
    }

    if (showPlaylists) {
        AlertDialog(
            onDismissRequest = { showPlaylists = false },
            containerColor = Color(0xFF171522),
            title = { Text("YOUR PLAYLISTS", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (playlists.isEmpty()) Text("No playlists yet. Create one to organize your music.", color = Color.LightGray)
                    playlists.sorted().forEach { name ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.QueueMusic, null, tint = Color(0xFFB78CFF))
                            Spacer(Modifier.width(8.dp))
                            Text(name, color = Color.White, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                playlists = playlists - name
                                preferences.edit().putStringSet("playlists", playlists).apply()
                            }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFB78CFF)) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPlaylists = false }) { Text("DONE") } }
        )
    }

    if (equalizerOpen) {
        AlertDialog(
            onDismissRequest = { equalizerOpen = false },
            containerColor = Color(0xFF171522),
            title = { Text("SOUND CONTROL", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    Modifier.fillMaxWidth().heightIn(max = 480.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        if (eqAvailable) "Device equalizer • ${eqLevels.size} bands" else "Equalizer is not available on this device yet",
                        color = Color(0xFFC9A9FF), fontSize = 12.sp
                    )
                    if (eqAvailable) {
                        val scroll = androidx.compose.foundation.rememberScrollState()
                        Column(Modifier.weight(1f, fill = false).verticalScroll(scroll)) {
                            eqLevels.forEachIndexed { index, level ->
                                Column(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(eqFrequencies.getOrElse(index) { "Band ${index + 1}" }, color = Color.White, modifier = Modifier.weight(1f), fontSize = 12.sp)
                                        Text("${"%.1f".format(level)} dB", color = Color(0xFFC9A9FF), fontSize = 11.sp)
                                    }
                                    Slider(
                                        value = level,
                                        onValueChange = { value ->
                                            eqLevels[index] = value
                                            try { equalizerEffect?.setBandLevel(index.toShort(), (value * 100).toInt().toShort()) } catch (_: Exception) { }
                                        },
                                        valueRange = eqRange
                                    )
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("BASS BOOST", color = Color.White, modifier = Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("${bassLevel.toInt()}%", color = Color(0xFFC9A9FF), fontSize = 12.sp)
                    }
                    Slider(
                        value = bassLevel,
                        onValueChange = { value ->
                            bassLevel = value
                            try { if (bassBoostEffect?.strengthSupported == true) bassBoostEffect?.setStrength((value * 10).toInt().toShort()) } catch (_: Exception) { }
                        },
                        valueRange = 0f..100f
                    )
                    Text("Available bands and effect support depend on your phone's audio hardware.", color = Color(0xFF9993A8), fontSize = 10.sp)
                }
            },
            confirmButton = { TextButton(onClick = { equalizerOpen = false }) { Text("DONE") } }
        )
    }

    Scaffold(
        containerColor = Color(0xFF090911),
        bottomBar = {
            Box(
                Modifier.fillMaxWidth().height(54.dp).background(Color(0xFF171725)),
                contentAlignment = Alignment.Center
            ) {
                Text("ADVERTISEMENT  •  AdMob banner slot", color = Color(0xFFAAA4BA), fontSize = 11.sp)
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(R.drawable.sonic_logo),
                    contentDescription = "Sonic 8D logo",
                    modifier = Modifier.size(46.dp)
                )
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("SONIC 8D", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("IMMERSIVE MUSIC PLAYER", color = Color(0xFF8E89A0), fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { equalizerOpen = true }) {
                    Icon(Icons.Default.Tune, contentDescription = "Equalizer", tint = Color.LightGray)
                }
            }

            Box(
                Modifier.fillMaxWidth().height(190.dp)
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF241044), Color(0xFF101D3B), Color(0xFF090911))),
                        RoundedCornerShape(24.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                CircularVisualizer(eightD)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("360°", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                    Text("SPATIAL VISUALIZER", color = Color(0xFFC8A9FF), fontSize = 10.sp, letterSpacing = 2.sp)
                }
            }

            LiveSpectrumGraph(bars = spectrumBars, isPlaying = playing)

            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("8D SPATIAL AUDIO", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(if (eightD) "Effect selected" else "Original audio mode", color = Color(0xFF9D98AA), fontSize = 11.sp)
                }
                Switch(checked = eightD, onCheckedChange = { eightD = it })
            }
            Text(
                "Live spectrum reads playback-session audio when permission is allowed. 8D spatial DSP is a separate development stage.",
                color = Color(0xFF8F899D), fontSize = 10.sp, lineHeight = 14.sp
            )

            Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("YOUR MUSIC", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { showPlaylists = true }) { Text("Playlists") }
                TextButton(onClick = { showCreatePlaylist = true }) { Text("+ New") }
                TextButton(onClick = { if (hasPermission()) tracks = loadTracks() else askForAudioPermission() }) { Text("Refresh") }
            }
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Search songs or artists") },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = Color(0xFFB78CFF)) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color(0xFFB78CFF),
                    unfocusedBorderColor = Color(0xFF393248),
                    cursorColor = Color(0xFFB78CFF)
                )
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                FilterChip(selected = !favoritesOnly, onClick = { favoritesOnly = false }, label = { Text("All songs") })
                FilterChip(selected = favoritesOnly, onClick = { favoritesOnly = true }, label = { Text("♥ Favorites (${favoriteIds.size})") })
            }

            val visibleTracks = tracks.withIndex().filter { (_, track) ->
                (!favoritesOnly || track.uri.toString() in favoriteIds) &&
                    (searchQuery.isBlank() || track.title.contains(searchQuery, ignoreCase = true) || track.artist.contains(searchQuery, ignoreCase = true))
            }

            if (!permissionGranted) {
                Button(onClick = { askForAudioPermission() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Allow access to audio")
                }
            } else if (tracks.isEmpty()) {
                Text("No music found. Add audio files to your phone and tap Refresh.", color = Color(0xFFAAA4BA), fontSize = 13.sp)
            } else if (visibleTracks.isEmpty()) {
                Text(if (favoritesOnly) "No favorite songs yet. Tap the heart beside a song." else "No songs match your search.", color = Color(0xFFAAA4BA), fontSize = 13.sp)
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                    itemsIndexed(visibleTracks) { _, indexedTrack ->
                        val index = indexedTrack.index
                        val track = indexedTrack.value
                        Row(
                            Modifier.fillMaxWidth().clickable { playTrack(index) }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(42.dp).background(Color(0xFF252039), CircleShape), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.MusicNote, null, tint = Color(0xFFB78CFF))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                                Text(track.artist, color = Color(0xFF918B9F), fontSize = 11.sp)
                            }
                            if (selected == index && playing) Icon(Icons.Default.Equalizer, null, tint = Color(0xFFB78CFF))
                            IconButton(onClick = { toggleFavorite(track) }) {
                                Icon(if (track.uri.toString() in favoriteIds) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (track.uri.toString() in favoriteIds) Color(0xFFFF6B9D) else Color(0xFFAAA4BA))
                            }
                        }
                        HorizontalDivider(color = Color(0xFF242333))
                    }
                }
            }

            if (selected >= 0 && selected < tracks.size) {
                Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text(tracks[selected].title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(tracks[selected].artist, color = Color(0xFF9993A8), fontSize = 11.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { if (tracks.isNotEmpty()) playTrack((selected - 1 + tracks.size) % tracks.size) }) {
                            Icon(Icons.Default.SkipPrevious, null, tint = Color.White)
                        }
                        IconButton(onClick = {
                            if (player.isPlaying) { player.pause(); playing = false }
                            else { player.play(); playing = true }
                        }) {
                            Icon(
                                if (playing) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                                null, tint = Color(0xFFB78CFF), modifier = Modifier.size(48.dp)
                            )
                        }
                        IconButton(onClick = { if (tracks.isNotEmpty()) playTrack((selected + 1) % tracks.size) }) {
                            Icon(Icons.Default.SkipNext, null, tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveSpectrumGraph(bars: List<Float>, isPlaying: Boolean) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("LIVE AUDIO GRAPH", color = Color(0xFFC9A9FF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.weight(1f))
            Text(if (isPlaying) "● LIVE" else "● STANDBY", color = if (isPlaying) Color(0xFF55D6FF) else Color(0xFF777184), fontSize = 9.sp)
        }
        Canvas(Modifier.fillMaxWidth().height(58.dp).padding(top = 7.dp)) {
            val count = bars.size.coerceAtLeast(1)
            val gap = 3.dp.toPx()
            val barWidth = ((size.width - gap * (count - 1)) / count).coerceAtLeast(1f)
            bars.forEachIndexed { index, level ->
                val h = (size.height * level.coerceIn(0.04f, 1f)).coerceAtLeast(3.dp.toPx())
                val x = index * (barWidth + gap)
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(Color(0xFF55D6FF), Color(0xFFB14CFF), Color(0xFF6D35D8)), startY = size.height - h, endY = size.height),
                    topLeft = Offset(x, size.height - h),
                    size = androidx.compose.ui.geometry.Size(barWidth, h),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2, barWidth / 2)
                )
            }
        }
    }
}

@Composable
private fun CircularVisualizer(active: Boolean) {
    val ringColor = if (active) Color(0xFF55D6FF) else Color(0xFFB78CFF)
    Canvas(Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2, size.height / 2)
        val maxRadius = size.minDimension * 0.39f
        for (i in 0..3) {
            drawCircle(
                color = ringColor.copy(alpha = 0.18f - i * 0.025f),
                radius = maxRadius - i * 13.dp.toPx(),
                center = center,
                style = Stroke(width = (2 + i).dp.toPx())
            )
        }
        for (i in 0 until 48) {
            val angle = Math.toRadians(i * 7.5)
            val inner = maxRadius * 0.72f
            val outer = inner + if (active) (12 + (i % 5) * 3).dp.toPx() else 8.dp.toPx()
            val start = Offset(center.x + kotlin.math.cos(angle).toFloat() * inner, center.y + kotlin.math.sin(angle).toFloat() * inner)
            val end = Offset(center.x + kotlin.math.cos(angle).toFloat() * outer, center.y + kotlin.math.sin(angle).toFloat() * outer)
            drawLine(ringColor.copy(alpha = 0.85f), start, end, strokeWidth = 2.dp.toPx())
        }
    }
}


@Composable
private fun SonicSplash() {
    var pulse by remember { mutableFloatStateOf(0.82f) }
    LaunchedEffect(Unit) {
        while (true) {
            pulse = 1.08f
            delay(650)
            pulse = 0.88f
            delay(650)
        }
    }
    val animatedScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = pulse,
        animationSpec = androidx.compose.animation.core.tween(650),
        label = "splashPulse"
    )
    Box(
        Modifier.fillMaxSize().background(
            Brush.radialGradient(listOf(Color(0xFF211044), Color(0xFF090911), Color.Black))
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.sonic_logo),
                contentDescription = "Sonic 8D",
                modifier = Modifier.size(190.dp).graphicsLayer(scaleX = animatedScale, scaleY = animatedScale)
            )
            Spacer(Modifier.height(22.dp))
            Text("SONIC 8D", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Spacer(Modifier.height(8.dp))
            Text("IMMERSIVE MUSIC PLAYER", color = Color(0xFFC7A5FF), fontSize = 10.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(28.dp))
            Box(Modifier.width(112.dp).height(3.dp).background(Color(0xFF34234E), RoundedCornerShape(50))) {
                Box(Modifier.fillMaxWidth(0.62f).fillMaxHeight().background(Color(0xFFB78CFF), RoundedCornerShape(50)))
            }
        }
    }
}

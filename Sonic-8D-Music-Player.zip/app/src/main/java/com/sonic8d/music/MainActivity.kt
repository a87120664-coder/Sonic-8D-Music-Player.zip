package com.sonic8d.music

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

private data class Track(val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            SonicTheme {
                SonicApp(
                    loadTracks = { queryAudio() },
                    player = player!!,
                    hasPermission = { audioPermissionGranted() }
                )
            }
        }
    }

    private fun audioPermissionGranted(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun queryAudio(): List<Track> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val result = mutableListOf<Track>()
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown title"
                val artist = cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
                result += Track(title, artist, Uri.withAppendedPath(collection, id.toString()))
            }
        }
        return result
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@Composable
private fun SonicTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = Color(0xFFB78CFF),
        secondary = Color(0xFF55D6FF),
        background = Color(0xFF090911),
        surface = Color(0xFF151522)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

@Composable
private fun SonicApp(
    loadTracks: () -> List<Track>,
    player: ExoPlayer,
    hasPermission: () -> Boolean
) {
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var selected by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    var eightD by remember { mutableStateOf(false) }
    var permissionGranted by remember { mutableStateOf(hasPermission()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted) tracks = loadTracks()
    }

    fun askForAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        permissionLauncher.launch(permission)
    }

    fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        selected = index
        player.setMediaItem(MediaItem.fromUri(tracks[index].uri))
        player.prepare()
        player.play()
        playing = true
    }

    LaunchedEffect(permissionGranted) {
        if (permissionGranted) tracks = loadTracks()
    }

    Scaffold(
        containerColor = Color(0xFF090911),
        bottomBar = {
            Box(
                Modifier.fillMaxWidth().height(54.dp).background(Color(0xFF171725)),
                contentAlignment = Alignment.Center
            ) {
                Text("ADVERTISEMENT  •  AdMob banner slot", color = Color(0xFFAAA4BA), fontSize = 11.sp)
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Headphones, null, tint = Color(0xFFB78CFF), modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("SONIC 8D", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("IMMERSIVE MUSIC PLAYER", color = Color(0xFF8E89A0), fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.LightGray)
            }

            Box(
                Modifier.fillMaxWidth().height(190.dp)
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF241044), Color(0xFF101D3B), Color(0xFF090911))),
                        RoundedCornerShape(24.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                CircularVisualizer(eightD)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("360°", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                    Text("SPATIAL VISUALIZER", color = Color(0xFFC8A9FF), fontSize = 10.sp, letterSpacing = 2.sp)
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("8D SPATIAL AUDIO", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(if (eightD) "Effect selected" else "Original audio mode", color = Color(0xFF9D98AA), fontSize = 11.sp)
                }
                Switch(checked = eightD, onCheckedChange = { eightD = it })
            }
            Text(
                "Starter preview: the 8D switch currently changes the interface only. True HRTF 3D audio processing is a separate next stage.",
                color = Color(0xFF8F899D), fontSize = 10.sp, lineHeight = 14.sp
            )

            Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("YOUR MUSIC", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    if (hasPermission()) tracks = loadTracks() else askForAudioPermission()
                }) { Text("Refresh") }
            }

            if (!permissionGranted) {
                Button(onClick = { askForAudioPermission() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Allow access to audio")
                }
            } else if (tracks.isEmpty()) {
                Text("No music found. Add audio files to your phone and tap Refresh.", color = Color(0xFFAAA4BA), fontSize = 13.sp)
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                    itemsIndexed(tracks) { index, track ->
                        Row(
                            Modifier.fillMaxWidth().clickable { playTrack(index) }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(42.dp).background(Color(0xFF252039), CircleShape), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.MusicNote, null, tint = Color(0xFFB78CFF))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                                Text(track.artist, color = Color(0xFF918B9F), fontSize = 11.sp)
                            }
                            if (selected == index && playing) Icon(Icons.Default.Equalizer, null, tint = Color(0xFFB78CFF))
                        }
                        HorizontalDivider(color = Color(0xFF242333))
                    }
                }
            }

            if (selected >= 0 && selected < tracks.size) {
                Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text(tracks[selected].title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(tracks[selected].artist, color = Color(0xFF9993A8), fontSize = 11.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { if (tracks.isNotEmpty()) playTrack((selected - 1 + tracks.size) % tracks.size) }) {
                            Icon(Icons.Default.SkipPrevious, null, tint = Color.White)
                        }
                        IconButton(onClick = {
                            if (player.isPlaying) { player.pause(); playing = false }
                            else { player.play(); playing = true }
                        }) {
                            Icon(
                                if (playing) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                                null, tint = Color(0xFFB78CFF), modifier = Modifier.size(48.dp)
                            )
                        }
                        IconButton(onClick = { if (tracks.isNotEmpty()) playTrack((selected + 1) % tracks.size) }) {
                            Icon(Icons.Default.SkipNext, null, tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CircularVisualizer(active: Boolean) {
    val ringColor = if (active) Color(0xFF55D6FF) else Color(0xFFB78CFF)
    Canvas(Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2, size.height / 2)
        val maxRadius = size.minDimension * 0.39f
        for (i in 0..3) {
            drawCircle(
                color = ringColor.copy(alpha = 0.18f - i * 0.025f),
                radius = maxRadius - i * 13.dp.toPx(),
                center = center,
                style = Stroke(width = (2 + i).dp.toPx())
            )
        }
        for (i in 0 until 48) {
            val angle = Math.toRadians(i * 7.5)
            val inner = maxRadius * 0.72f
            val outer = inner + if (active) (12 + (i % 5) * 3).dp.toPx() else 8.dp.toPx()
            val start = Offset(center.x + kotlin.math.cos(angle).toFloat() * inner, center.y + kotlin.math.sin(angle).toFloat() * inner)
            val end = Offset(center.x + kotlin.math.cos(angle).toFloat() * outer, center.y + kotlin.math.sin(angle).toFloat() * outer)
            drawLine(ringColor.copy(alpha = 0.85f), start, end, strokeWidth = 2.dp.toPx())
        }
    }
}
